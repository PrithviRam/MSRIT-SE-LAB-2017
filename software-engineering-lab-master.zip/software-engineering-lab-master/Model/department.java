
import java.util.*;

/**
 * 
 */
public class department {

    /**
     * Default constructor
     */
    public department() {
    }

    /**
     * 
     */
    public string name;

    /**
     * 
     */
    public string faculty;



    /**
     * 
     */
    public void addcourse() {
        // TODO implement here
    }

    /**
     * 
     */
    public void removecourse() {
        // TODO implement here
    }

}