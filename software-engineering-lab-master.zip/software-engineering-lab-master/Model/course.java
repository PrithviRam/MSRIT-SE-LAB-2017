
import java.util.*;

/**
 * 
 */
public class course {

    /**
     * Default constructor
     */
    public course() {
    }

    /**
     * 
     */
    public string name;

    /**
     * 
     */
    public string code;

    /**
     * 
     */
    public string credits;



    /**
     * 
     */
    public void getcourse() {
        // TODO implement here
    }

    /**
     * 
     */
    public void setcourse() {
        // TODO implement here
    }

}