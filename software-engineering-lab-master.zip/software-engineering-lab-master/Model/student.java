
import java.util.*;

/**
 * 
 */
public class student {

    /**
     * Default constructor
     */
    public student() {
    }

    /**
     * 
     */
    public string name;

    /**
     * 
     */
    public string usn;

    /**
     * 
     */
    public string phone num;

    /**
     * 
     */
    public string branch;







    /**
     * 
     */
    public void selectdept() {
        // TODO implement here
    }

    /**
     * 
     */
    public void selectcourse() {
        // TODO implement here
    }

    /**
     * 
     */
    public void login() {
        // TODO implement here
    }

    /**
     * 
     */
    public void logout() {
        // TODO implement here
    }

}